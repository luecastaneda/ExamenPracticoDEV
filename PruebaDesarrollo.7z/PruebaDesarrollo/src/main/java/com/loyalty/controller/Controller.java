package com.loyalty.controller;


import com.loyalty.interfaces.IProcess;
import com.loyalty.request.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/postfix")
public class Controller {
    private IProcess<Object,String> postFixProcess;

    @Autowired
    public Controller(IProcess<Object, String> postFixProcess) {
        this.postFixProcess = postFixProcess;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{evaluate}")
    public Object evaluate(@RequestBody Request evaluateRequest){
        return postFixProcess.process(evaluateRequest.getExp());
    }
}
