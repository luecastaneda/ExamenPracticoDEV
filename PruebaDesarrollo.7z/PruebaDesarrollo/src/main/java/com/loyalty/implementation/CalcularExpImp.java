package com.loyalty.implementation;


import com.loyalty.interfaces.ICalcularExp;
import com.loyalty.response.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Stack;

@Service("CalcularExpImp")
public class CalcularExpImp implements ICalcularExp {

    @Override
    public Object calcularValor(Object Exp){
        ErrorResponse errorResponse=new ErrorResponse();
        Stack<String> operators = new Stack<String>();
        Stack<String> numbers = new Stack<String>();
        Double val1=0.0,val2=0.0;

        char topOp=' ',temp=' ',t=' ';
        String dec=new String();
       // char[] input=((IntPipeline.Head) ((String) Exp).chars()).sourceSupplier;

        try{

            for(int i=0;i<Exp.toString().length();i++){
                t=Exp.toString().charAt(i);

                if(Character.isDigit(t) || t=='.') {
                    numbers.push(String.valueOf(t));

                }else{
                    if(t=='[' | t==']') continue;
                    val1=Double.valueOf(numbers.pop());
                    topOp=numbers.pop().charAt(0);
                    if(numbers.peek().charAt(0)=='.'){
                        dec= new StringBuilder().append(topOp).append(numbers.pop().charAt(0)).toString();
                        dec=dec.concat(String.valueOf(numbers.pop().charAt(0)));
                        val2=Double.valueOf(dec);

                    }else{
                        val2=Double.valueOf(topOp);
                    }
                    switch(t)
                    {
                        case '+':
                            numbers.push(String.valueOf(val2+val1));
                            break;

                        case '-':
                            numbers.push(String.valueOf(val2-val1));
                            break;

                        case '/':
                            numbers.push(String.valueOf(val2/val1));
                            break;

                        case '*':
                            numbers.push(String.valueOf(val2*val1));
                            break;
                    }
                }

            }




        }catch (Exception e){
            errorResponse.setMessage("Some error ocurred while processing the expression");
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        return numbers.pop();
    }
}
