package com.loyalty.implementation;

import com.loyalty.interfaces.IPostFixExpression;
import com.loyalty.response.ErrorResponse;
import com.loyalty.utils.OperatorsUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Stack;

@Service("PostFixExpressionImp")
public class PostFixExpressionImp implements  IPostFixExpression{
    //private IPostFixExpression iPostFixExpression;
    private Environment env;

    @Autowired
    public PostFixExpressionImp(Environment env) {
        this.env = env;
    }

    @Override
    public Object evaluarExpresion(String infixExp){
        ErrorResponse errorResponse=new ErrorResponse();
        String supported_operators = env.getProperty("app-properties.operator");
        Stack<String> operators = new Stack<String>();
        Stack<String> output = new Stack<String>();
        char topOp=' ',tempOp=' ';

        try{
            int i=1;
            char[] input=infixExp.toCharArray();

            for(char t : input){
                if(Character.isDigit(t) || t=='.'){
                    output.push(String.valueOf(t));
                }else{
                    if(supported_operators.contains(String.valueOf(t))){
                        if(!operators.empty()){
                            topOp=operators.peek().charAt(0);
                            if(OperatorsUtils.precedence(t)>OperatorsUtils.precedence(topOp)){
                                tempOp= operators.pop().charAt(0);
                                operators.push(String.valueOf(tempOp));
                                operators.push(String.valueOf(t));
                                continue;
                            }else{
                                tempOp= operators.pop().charAt(0);
                                output.push(String.valueOf(tempOp));
                                operators.push(String.valueOf(t));
                                continue;
                            }
                        }
                        operators.push(String.valueOf(t));
                        continue;
                    }
                    errorResponse.setMessage("The expresion "+infixExp+" is invalid");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }
            }
            while(!operators.empty()) output.push(operators.pop());

        }catch (Exception e){
            errorResponse.setMessage("Some error ocurred while processing the expression");
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return output.toString();
    }
}
