package com.loyalty.implementation;

import com.loyalty.interfaces.ICalcularExp;
import com.loyalty.interfaces.IPostFixExpression;
import com.loyalty.interfaces.IProcess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service("PostfixProcess")
public class PostfixProcess implements IProcess<Object,String> {
    private IPostFixExpression iPostFixExpression;
    private ICalcularExp iCalcularExp;


    @Autowired
    public PostfixProcess(IPostFixExpression iPostFixExpression,ICalcularExp iCalcularExp) {
        this.iPostFixExpression = iPostFixExpression;
        this.iCalcularExp=iCalcularExp;
    }
    @Override
    public Object process(String[] params){
        try {
            //if (ValidaExp.process(params[0]))
            Object infix = iPostFixExpression.evaluarExpresion(params[0]);
            return iCalcularExp.calcularValor(infix);
        } catch(Exception e){
            return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
