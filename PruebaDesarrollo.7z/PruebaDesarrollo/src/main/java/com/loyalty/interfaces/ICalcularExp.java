package com.loyalty.interfaces;

public interface ICalcularExp {
    Object calcularValor(Object Exp);
}
