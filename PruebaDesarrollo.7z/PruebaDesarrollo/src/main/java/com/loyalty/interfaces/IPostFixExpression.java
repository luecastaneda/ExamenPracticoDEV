package com.loyalty.interfaces;

public interface IPostFixExpression {
    Object evaluarExpresion(String infixExp);

}
