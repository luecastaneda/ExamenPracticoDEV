package com.loyalty.utils;

public class OperatorsUtils {
    public static int precedence(Character op) {
        if (op.equals('+') || op.equals('-')) return 2;
        else if (op.equals('*') || op.equals('/')) return 3;

        return -1;
    }


}
