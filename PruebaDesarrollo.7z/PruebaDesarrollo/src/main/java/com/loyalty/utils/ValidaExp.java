package com.loyalty.utils;

public class ValidaExp {

    public static boolean process(String Exp){
        if(!Exp.isEmpty()){
            char[] T=Exp.toCharArray();
            if(T.length>=3 & T[0]!='-'){
                return true;
            }
        }
        return false;
    }
}
