package com.loyalty.PruebaDesarrollo;

import com.loyalty.utils.ValidaExp;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles("testing")
class PruebaDesarrolloApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void isNotEmpty(){
		Assert.assertTrue(ValidaExp.process("1+2"));
	}

	@Test
	void isEmpty(){
		Assert.assertFalse(ValidaExp.process(""));
	}

}
