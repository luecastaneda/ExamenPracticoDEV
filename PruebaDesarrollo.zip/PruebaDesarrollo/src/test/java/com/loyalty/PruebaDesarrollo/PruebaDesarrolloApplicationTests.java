package com.loyalty.PruebaDesarrollo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaDesarrolloApplicationTests {

	@Test
	void contextLoads() {
	}

}
